OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "منسوخ کریں",
    "Shared by" : "سے اشتراک شدہ",
    "Password" : "پاسورڈ",
    "Name" : "اسم",
    "Download" : "ڈاؤن لوڈ،"
},
"nplurals=2; plural=(n != 1);");
