OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "ပယ်ဖျက်မည်",
    "Password" : "စကားဝှက်",
    "Download" : "ဒေါင်းလုတ်"
},
"nplurals=1; plural=0;");
