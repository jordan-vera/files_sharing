OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "لابردن",
    "Password" : "وشەی تێپەربو",
    "Name" : "ناو",
    "Download" : "داگرتن"
},
"nplurals=2; plural=(n != 1);");
