OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "Cancellar",
    "A file or folder has been <strong>shared</strong>" : "Un file o un dossier ha essite <strong>compartite</strong>",
    "You shared %1$s with %2$s" : "Tu compartiva %1$s con %2$s",
    "You shared %1$s with group %2$s" : "Tu compartiva %1$s con gruppo %2$s",
    "You shared %1$s via link" : "Tu compartiva %1$s via ligamine",
    "%2$s shared %1$s with you" : "%2$s compartiva %1$s con te",
    "Shares" : "Comparti",
    "Password" : "Contrasigno",
    "Name" : "Nomine",
    "Download" : "Discargar"
},
"nplurals=2; plural=(n != 1);");
