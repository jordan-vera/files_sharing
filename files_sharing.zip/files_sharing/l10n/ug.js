OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "ۋاز كەچ",
    "Shared by" : "ھەمبەھىرلىگۈچى",
    "Sharing" : "ھەمبەھىر",
    "Password" : "ئىم",
    "Name" : "ئاتى",
    "Download" : "چۈشۈر"
},
"nplurals=1; plural=0;");
