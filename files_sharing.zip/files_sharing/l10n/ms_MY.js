OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "Batal",
    "Shared by" : "Dikongsi dengan",
    "You shared %1$s via link" : "Anda kongsikan %1$s melalui sambungan",
    "%2$s shared %1$s with you" : "%2$s berkongsi %1$s dengan anda",
    "Shares" : "Kongsi",
    "Password" : "Kata laluan",
    "Name" : "Nama",
    "Download" : "Muat turun"
},
"nplurals=1; plural=0;");
