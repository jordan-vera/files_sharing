OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "रद्द करें ",
    "Shared by" : "द्वारा साझा",
    "Password" : "पासवर्ड"
},
"nplurals=2; plural=(n != 1);");
