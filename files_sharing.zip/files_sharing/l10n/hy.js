OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "Չեղարկել",
    "Password" : "Գաղտնաբառ",
    "Name" : "Անուն",
    "Download" : "Ներբեռնել",
    "Download %s" : "Ներբեռնել %s"
},
"nplurals=2; plural=(n != 1);");
