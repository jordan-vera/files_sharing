OC.L10N.register(
    "files_sharing",
    {
    "Cancel" : "取消",
    "Sharing" : "分享",
    "A file or folder has been <strong>shared</strong>" : "檔案或資料夾已被<strong>分享</strong>",
    "You shared %1$s with %2$s" : "你分享了 %1$s 給 %2$s",
    "Shares" : "分享",
    "Password" : "密碼",
    "Name" : "名稱",
    "Download" : "下載"
},
"nplurals=1; plural=0;");
